
#define F_CPU 8000000UL //definir F_CPU a 8MGHZ

#include <xc.h>
#include "avr/io.h"
#include <util/delay.h>
#include "avr/interrupt.h"
#include <stdio.h>

#define PIN_RELEVADOR1 PD4
#define PIN_RELEVADOR2 PD5
#define PIN_RELEVADOR3 PD6
#define BUZZER_PIN PD7
uint32_t segundos=0;

int limite= 20;
int minutos, horasS;
uint8_t adcl_value, adch_value;
uint16_t adc_value;
int signal;
int potencia;
int adc_pot;
int potencia_temp;

int voltage;
int corriente;
int rms;
int num_potencia;

int max = 0;

#define rs PB2
#define en PB3

void lcd_init();
void dis_cmd(char);
void dis_data(char);
void lcdcmd(char);
void lcddata(char);
//int get_potencia(int);
void send_adc(uint16_t value);
void usart_init(void);
uint16_t get_adc(uint8_t canal);
void DesactivarRelevador(void);
void ActivarRelevador(void);

int main(void){
	// Comunicacion Serial
	DDRD |= (1<<PD1);
	//Pines de Relevador
	DDRD |= (1 << PIN_RELEVADOR1); // PD4 como salida
	DDRD |= (1 << PIN_RELEVADOR2);
	DDRD |= (1 << PIN_RELEVADOR3);
	//Pin buzzer
	DDRD |= (1 << BUZZER_PIN); //buzzer
	//Habilitar interrupciones externnas
	GICR = 0b011000000;
	MCUCR= 0b00001010;
	// Desactivar el relevador (cerrar el circuito)
	DesactivarRelevador();
	// TIMER 1 (RTC)
	OCR1A=7811;
	TCCR1A=0;
	TCCR1B=0b00001101;
	TIMSK = (1<<OCIE1A);
	sei();
	// iNICIALIZAR Configurar Serial
	usart_init();
	//inicializar lcd
	lcd_init();
	//send_adc(get_adc(0));
	// Configurar ADC
	ADCSRA= 0b10000111;
	ADMUX= 0b01000001;// 11000000
	ADCSRA |= (1<<ADIF);
	
	//PRUEBA
	DDRC = 0xFF;

	//LCD CONFIGURACI�N
	unsigned char data0[] = "SENSOR: 1";
	unsigned char data1[] = "SENSOR: 2";
	unsigned char num_potencia[10];
	unsigned char unidad[] = " W/H      ";
	int i=0;
	DDRB=0xFF;
	

	while(1){
		if (segundos == limite) // Tiempo que sera el limite para activar los relevadores
		{
			ActivarRelevador();
		}
		max = 0;
		if(ADMUX >= 0b01000011){
			ADMUX = 0b01000000;
		}
		
		//Potencia
		potencia = get_adc(0);
		
		for(int i = 0; i < 1500; i++){
			if(potencia > max){
				max = potencia;
			}
			_delay_ms(1);
		}
		
		if (max < 511){
			max = 511;
		}
		
		max = (((max* .05) - 2)*85);
		max =max * 0.7*.1;
		
		if (max < 0){
			max *= -1;
		}

		_delay_ms(500);

		
		sprintf(num_potencia, "%d", max);
		send_adc(max);
		if (ADMUX == 0b01000000){
			while(data0[i]!='\0'){
				dis_data(data0[i]);
				_delay_ms(100);
				i++;
				
			}
			
		}
		
		else if (ADMUX == 0b01000010){
			while(data1[i]!='\0'){
				dis_data(data1[i]);
				_delay_ms(100);
				i++;
			}
		}
		
		dis_cmd(0xC3);
		
		i=0;
		while(num_potencia[i]!='\0'){
			dis_data(num_potencia[i]);
			_delay_ms(100);
			i++;
		}
		
		dis_cmd(0xC6);
		i=0;
		while(unidad[i]!='\0'){
			dis_data(unidad[i]);
			_delay_ms(100);
			i++;
		}
		
		//ADMUX ++;

	}
	_delay_ms(10000);
	return 0;
	
}
ISR (INT0_vect) // boton para reiniciar el contador
{
	_delay_ms(10);
	segundos = 0;

}

ISR (INT1_vect) // boton para evitar el apagado
{
	_delay_ms(10);
	//relevador = 0 ;
}

ISR(TIMER1_COMPA_vect) {
	// Incrementar la variable de segundos
	segundos++;
	if(segundos> limite-9 && segundos < limite)
	{
		// Encender el buzzer
		PORTD ^= (1 << BUZZER_PIN);
	}
	
	if(segundos==60)
	{
		segundos=0;
		minutos++;
		if(minutos=60)
		{
			horas++;
			if (horas==24)
			{
				horas=0;
			}
		}
	}
}
void DesactivarRelevador(void) //  cerrar el circuito
{
	PORTD |= (1 << PIN_RELEVADOR1);
	PORTD |= (1 << PIN_RELEVADOR2);
	PORTD |= (1 << PIN_RELEVADOR3);
}

void ActivarRelevador(void)
{
	// Activar el relevador (abrir el circuito) // NO CARGA
	PORTD &= ~(1 << PIN_RELEVADOR1);
	PORTD &= ~(1 << PIN_RELEVADOR2);
	PORTD &= ~(1 << PIN_RELEVADOR3);
}

uint16_t get_adc(uint8_t canal)
{
	canal &= 0b00000111;
	ADMUX |= canal;
	ADCSRA |= (1<<ADSC); //inicio de conversion
	while((ADCSRA&(1<<ADIF))==0); //esperar fin de la conversion
	ADCSRA |= (1<<ADIF);
	adcl_value = ADCL;
	adch_value = ADCH;
	adc_value = (adch_value << 8) + (adcl_value);
	if(adc_value >= 0x8000)
	{
		adc_value = adc_value - 0x8000;
	}
	return adc_value;
}

// fuction for intialize
void lcd_init(){
	dis_cmd(0x02);		// to initialize LCD in 4-bit mode.
	dis_cmd(0x28);
	//dis_cmd(0x01);	                  	//to initialize LCD in 2 lines, 5X7 dots and 4bit mode.
	dis_cmd(0x0C);
	dis_cmd(0x06);
	dis_cmd(0x83);
}

void dis_cmd(char cmd_value){
	char cmd_value1;
	
	cmd_value1 = cmd_value & 0xF0;		//mask lower nibble because PA4-PA7 pins are used.
	lcdcmd(cmd_value1);			// send to LCD
	
	cmd_value1 = ((cmd_value<<4) & 0xF0);	//shift 4-bit and mask
	lcdcmd(cmd_value1);			// send to LCD
}


void dis_data(char data_value){
	char data_value1;
	
	data_value1=data_value&0xF0;
	lcddata(data_value1);
	
	data_value1=((data_value<<4)&0xF0);
	lcddata(data_value1);
}

void lcdcmd(char cmdout){
	PORTB=cmdout;
	PORTB&=~(1<<rs);
	//PORTB&=~(1<<rw);
	PORTB|=(1<<en);
	_delay_ms(1);
	PORTB&=~(1<<en);
}

void lcddata(char dataout){
	PORTB=dataout;
	PORTB|=(1<<rs);
	//PORTB&=~(1<<rw);
	PORTB|=(1<<en);
	_delay_ms(1);
	PORTB&=~(1<<en);
}


void usart_init(void)
{
	UCSRA = 0;
	UCSRB |=(1<<TXEN);
	UCSRC |= (1 << URSEL) | (1 << UCSZ0) | (1 << UCSZ1);
	UBRRL=51;
	UBRRH=0;
	
}
void send_adc(uint16_t value)
{
	uint8_t adc_alto= (uint8_t) (value>>8);
	uint8_t adc_bajo= (uint8_t)(value);
	UDR = adc_alto; // mandar datos en el udr y se escrube en el buffer de Tx
	while(!(UCSRA & (1<<UDRE))); //Bandera de buffer de transmicion vacio
	UDR= adc_bajo;
	while(!(UCSRA & (1<<UDRE)));
	_delay_ms(10);
}